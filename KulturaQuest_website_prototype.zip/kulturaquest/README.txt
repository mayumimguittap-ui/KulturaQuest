KULTURAQUEST WEBSITE PROTOTYPE
==============================

Included:
- index.html: responsive, single-page KulturaQuest prototype
- Working sample multiple-choice quiz
- Navigation links and sections based on your revised proposal
- Sample visual placeholders and content notes for research/verification

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open the kulturaquest folder.
3. Double-click index.html. It opens in your browser.
4. Internet is needed for the sample images because they are loaded from image URLs.

HOW TO PUBLISH FOR FREE (GitHub Pages)
1. Create/sign in to a GitHub account: https://github.com/
2. Create a new public repository named kulturaquest
3. Upload index.html to the repository's main/root folder.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish. Your public URL will appear in Settings > Pages.

IMPORTANT BEFORE PUBLIC RELEASE
- Replace sample images with images you own, have permission to use, or that have a suitable reuse license.
- Add proper source citations and image credits.
- Verify local Ilocos Norte information with reliable sources and, where appropriate, local artists or cultural knowledge holders.
- Do not publish interviews, names, photos, or culturally sensitive material without permission.
- Test the public link in a private/incognito browser window.
- This is a front-end prototype. It does not yet have user accounts, stored scores, a database, or an admin dashboard. The sample quiz runs in the visitor's browser only.
